//@line 2 "c:\Users\Stefano\DOMinator_Src\srcs\browser\app\profile\channel-prefs.js"
pref("app.update.channel", "default");
